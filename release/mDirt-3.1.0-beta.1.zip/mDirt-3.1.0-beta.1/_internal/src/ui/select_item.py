# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'select-itemaygDNU.ui'
##
## Created by: Qt User Interface Compiler version 6.8.1
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (
    QCoreApplication,
    QDate,
    QDateTime,
    QLocale,
    QMetaObject,
    QObject,
    QPoint,
    QRect,
    QSize,
    QTime,
    QUrl,
    Qt,
)
from PySide6.QtGui import (
    QBrush,
    QColor,
    QConicalGradient,
    QCursor,
    QFont,
    QFontDatabase,
    QGradient,
    QIcon,
    QImage,
    QKeySequence,
    QLinearGradient,
    QPainter,
    QPalette,
    QPixmap,
    QRadialGradient,
    QTransform,
)
from PySide6.QtWidgets import (
    QApplication,
    QComboBox,
    QFormLayout,
    QLabel,
    QPushButton,
    QSizePolicy,
    QWidget,
)


class Ui_Form(object):
    def setupUi(self, Form):
        if not Form.objectName():
            Form.setObjectName("Form")
        Form.resize(331, 70)
        self.formLayout = QFormLayout(Form)
        self.formLayout.setObjectName("formLayout")
        self.label = QLabel(Form)
        self.label.setObjectName("label")

        self.formLayout.setWidget(0, QFormLayout.LabelRole, self.label)

        self.itemsBox = QComboBox(Form)
        self.itemsBox.setObjectName("itemsBox")
        self.itemsBox.setEditable(True)

        self.formLayout.setWidget(0, QFormLayout.FieldRole, self.itemsBox)

        self.pushButton = QPushButton(Form)
        self.pushButton.setObjectName("pushButton")

        self.formLayout.setWidget(1, QFormLayout.FieldRole, self.pushButton)

        self.retranslateUi(Form)

        QMetaObject.connectSlotsByName(Form)

    # setupUi

    def retranslateUi(self, Form):
        Form.setWindowTitle(QCoreApplication.translate("Form", "Select Item", None))
        self.label.setText(QCoreApplication.translate("Form", "Select Your Item", None))
        # if QT_CONFIG(tooltip)
        self.itemsBox.setToolTip(
            QCoreApplication.translate(
                "Form", "<html><head/><body><p>Sets the item!</p></body></html>", None
            )
        )
        # endif // QT_CONFIG(tooltip)
        # if QT_CONFIG(tooltip)
        self.pushButton.setToolTip(
            QCoreApplication.translate(
                "Form", "<html><head/><body><p>Sets the item!</p></body></html>", None
            )
        )
        # endif // QT_CONFIG(tooltip)
        self.pushButton.setText(QCoreApplication.translate("Form", "OK", None))

    # retranslateUi
